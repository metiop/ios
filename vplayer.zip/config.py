HEROKU = False  # NOTE Make it false if you're not deploying on heroku.

# NOTE these values are for heroku.
if HEROKU:
    from os import environ

    API_ID = int(environ["API_ID"])
    API_HASH = environ["API_HASH"]
    SUDO_CHAT_ID = int(
        environ["SUDO_CHAT_ID"]
    )  # Chat where the bot will play the music.
    SUDOERS = list(
        int(x) for x in environ.get("SUDOERS", "").split()
    )  # Users which have special control over the bot.
    SESSION_STRING = environ["SESSION_STRING"]  # Check Readme for session
    ARQ_API_KEY = environ["ARQ_API_KEY"]

# NOTE Fill this if you are not deploying on heroku.
if not HEROKU:
    API_ID = 7273371
    API_HASH = "553337e711993d5be5dd95b61781eb4b"
    SUDO_CHAT_ID = -1001900060993
    SUDOERS = [1900060993 , 1219147672 ]
    ARQ_API_KEY = "SINOAY-QWAZJC-YVADAV-VIRGPF-ARQ"
# don't make changes below this line
ARQ_API = "https://thearq.tech"
