HELP_TEXT = """__**I Can Play Music In The Voice Chat**__

**/help** __Show This Message.__
**/skip** __Skip The Current Playing Music.__
**/play** __youtube/saavn/deezer Song_Name__
**/telegram** __Play From Telegram Audio.__
**/joinvc** __Join Voice Chat.__
**/leavevc** __Leave Voice Chat.__
**/volume [1-200]** __Adjust Volume.__
**/pause** __Pause Music.__
**/resume** __Resume Music.__
**/update** __Update & Restart.__"""

START_TEXT = "__**Hi I'm Telegram Voice Chat Bot. Join @metiwz_team  For Support.**__"

REPO_TEXT = (
    
     " | [Group](t.me/metiwz_team)"
)
